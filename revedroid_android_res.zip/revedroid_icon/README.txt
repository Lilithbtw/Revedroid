Revedroid launcher icon

1. Copy the res/ folder into app/src/main/res/ (merge).
2. Manifest: android:icon="@mipmap/ic_launcher" and android:roundIcon="@mipmap/ic_launcher_round".
3. Android 13+ with "Themed icons" on: the launcher tints res/drawable/ic_revedroid_monochrome.xml
   with the wallpaper (Material You) colors. Everywhere else the full-color layers are used.

svg/ holds the editable sources on the 108x108 adaptive canvas (keep artwork inside the
centered 66x66 safe zone). revedroid_icon_512.png is a full-bleed 512x512 fallback
(Play Store size; also usable as the source for legacy mipmaps if minSdk < 26).
